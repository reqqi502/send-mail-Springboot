# spring-boot-email-freemarker
Spring Mail - Sending Email with &lt;#Freemarker> HTML Template Example
